# recursionfunctions

This library was created to show functions that help with returning  different forms of sorting and recursion algorithms.

## Build this package locally

python setup.py sdist

##installing this package from GitHub
pip install git+https://github.com/MakayM/recursionfunctions.git

##updating this package locally
pip install --upgrade git+https://github.com/MakayM/recursionfunctions.git
